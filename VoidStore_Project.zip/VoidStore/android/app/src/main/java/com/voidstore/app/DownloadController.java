package com.voidstore.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DownloadController {
    public interface Listener {
        void onState(String state, long done, long total, String message);
    }

    private final Activity activity;
    private final JSONObject app;
    private final Listener listener;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private volatile boolean paused;
    private volatile boolean cancelled;
    private volatile boolean running;
    private volatile HttpURLConnection active;
    private File partFile;
    private File finalFile;

    public DownloadController(Activity activity, JSONObject app, Listener listener) {
        this.activity = activity;
        this.app = app;
        this.listener = listener;
        try {
            File dir = new File(activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "apks");
            dir.mkdirs();
            String base = safe(app.getString("packageName")) + "-" + app.getLong("versionCode");
            partFile = new File(dir, base + ".apk.part");
            finalFile = new File(dir, base + ".apk");
        } catch (Exception ignored) {}
    }

    public boolean isRunning() { return running; }
    public boolean isPaused() { return paused && !cancelled; }

    public void startOrResume() {
        if (running) return;
        if (Build.VERSION.SDK_INT >= 26 && !activity.getPackageManager().canRequestPackageInstalls()) {
            listener.onState("permission", 0, 0, "Installation aus dieser Quelle erlauben.");
            Intent s = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(s);
            return;
        }
        cancelled = false;
        paused = false;
        running = true;
        io.execute(this::downloadLoop);
    }

    public void pause() {
        if (!running) return;
        paused = true;
        HttpURLConnection c = active;
        if (c != null) c.disconnect();
    }

    public void cancel() {
        cancelled = true;
        paused = false;
        HttpURLConnection c = active;
        if (c != null) c.disconnect();
        if (partFile != null) partFile.delete();
        if (finalFile != null) finalFile.delete();
        listener.onState("cancelled", 0, 0, "Download abgebrochen");
    }

    public long downloadedBytes() { return partFile != null && partFile.exists() ? partFile.length() : 0; }

    private void downloadLoop() {
        long start = downloadedBytes();
        try {
            String downloadUrl = app.getString("downloadUrl");
            HttpURLConnection conn = StoreApi.openDownload(activity, downloadUrl, start);
            active = conn;
            int code = conn.getResponseCode();
            if (code != 200 && code != 206) throw new Exception("Downloadfehler " + code);
            if (start > 0 && code == 200) {
                start = 0;
                if (partFile.exists()) partFile.delete();
            }
            long remaining = conn.getContentLengthLong();
            long total = remaining > 0 ? start + remaining : app.optLong("sizeBytes", -1);
            listener.onState("downloading", start, total, "Download läuft");
            try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(partFile, start > 0)) {
                byte[] buf = new byte[64 * 1024];
                long done = start;
                int n;
                while ((n = in.read(buf)) >= 0) {
                    if (cancelled) return;
                    if (paused) {
                        running = false;
                        listener.onState("paused", done, total, "Pausiert");
                        return;
                    }
                    out.write(buf, 0, n);
                    done += n;
                    listener.onState("downloading", done, total, "Download läuft");
                }
            }
            if (cancelled || paused) return;
            if (finalFile.exists()) finalFile.delete();
            if (!partFile.renameTo(finalFile)) throw new Exception("Download-Datei konnte nicht abgeschlossen werden.");
            running = false;
            listener.onState("ready", finalFile.length(), finalFile.length(), "Bereit zur Installation");
            activity.runOnUiThread(this::openInstaller);
        } catch (Exception e) {
            running = false;
            if (cancelled) return;
            if (paused) {
                listener.onState("paused", downloadedBytes(), app.optLong("sizeBytes", -1), "Pausiert");
                return;
            }
            listener.onState("error", downloadedBytes(), app.optLong("sizeBytes", -1), e.getMessage());
        } finally {
            active = null;
        }
    }

    private void openInstaller() {
        if (finalFile == null || !finalFile.exists()) return;
        Uri uri = Uri.parse("content://" + activity.getPackageName() + ".files/" + Uri.encode(finalFile.getName()));
        Intent install = new Intent(Intent.ACTION_VIEW);
        install.setDataAndType(uri, "application/vnd.android.package-archive");
        install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(install);
    }

    private static String safe(String s) { return s.replaceAll("[^A-Za-z0-9_.-]", "_"); }
}
