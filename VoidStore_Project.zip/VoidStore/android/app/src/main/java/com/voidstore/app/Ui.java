package com.voidstore.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    public static final int BG = Color.rgb(11,9,16);
    public static final int SURFACE = Color.rgb(23,19,30);
    public static final int SURFACE_2 = Color.rgb(31,26,40);
    public static final int PURPLE = Color.rgb(169,112,255);
    public static final int PURPLE_2 = Color.rgb(201,178,255);
    public static final int TEXT = Color.rgb(248,245,255);
    public static final int MUTED = Color.rgb(176,168,191);
    public static final int GOOD = Color.rgb(120,224,166);
    public static final int DANGER = Color.rgb(255,115,132);

    private Ui() {}

    public static int dp(Activity a, int v) {
        return Math.round(v * a.getResources().getDisplayMetrics().density);
    }

    public static TextView text(Activity a, String s, int sp, boolean bold) {
        TextView v = new TextView(a);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(TEXT);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    public static TextView muted(Activity a, String s, int sp) {
        TextView v = text(a, s, sp, false);
        v.setTextColor(MUTED);
        return v;
    }

    public static GradientDrawable rounded(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    public static Button primary(Activity a, String label) {
        Button b = new Button(a);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.rgb(20,12,28));
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(rounded(PURPLE, dp(a, 18)));
        b.setPadding(dp(a, 18), 0, dp(a, 18), 0);
        return b;
    }

    public static Button secondary(Activity a, String label) {
        Button b = new Button(a);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setBackground(rounded(SURFACE_2, dp(a, 18)));
        b.setPadding(dp(a, 18), 0, dp(a, 18), 0);
        return b;
    }

    public static Button danger(Activity a, String label) {
        Button b = secondary(a, label);
        b.setTextColor(DANGER);
        return b;
    }

    public static EditText input(Activity a, String hint) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(125,118,139));
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setPadding(dp(a, 15), dp(a, 12), dp(a, 15), dp(a, 12));
        e.setBackground(rounded(SURFACE_2, dp(a, 16)));
        return e;
    }

    public static LinearLayout card(Activity a) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(a, 16), dp(a, 16), dp(a, 16), dp(a, 16));
        c.setBackground(rounded(SURFACE, dp(a, 22)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(a, 12);
        c.setLayoutParams(p);
        return c;
    }

    public static LinearLayout row(Activity a) {
        LinearLayout r = new LinearLayout(a);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    public static View spacer(Activity a, int height) {
        View v = new View(a);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(a, height)));
        return v;
    }
}
