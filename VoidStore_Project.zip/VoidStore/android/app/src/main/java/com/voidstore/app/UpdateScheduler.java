package com.voidstore.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public final class UpdateScheduler {
    private UpdateScheduler() {}
    public static void schedule(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(context, UpdateReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, 7002, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long first = System.currentTimeMillis() + 30 * 60 * 1000L;
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, first, 6 * 60 * 60 * 1000L, pi);
    }
}
