package com.voidstore.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

public class UpdateReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (StoreApi.server(context).isEmpty()) return;
        PendingResult pending = goAsync();
        new Thread(() -> {
            try {
                JSONArray apps = StoreApi.getApps(context);
                int count = 0; String name = null;
                for (int i = 0; i < apps.length(); i++) {
                    JSONObject app = apps.getJSONObject(i);
                    try {
                        PackageInfo p = context.getPackageManager().getPackageInfo(app.getString("packageName"), 0);
                        long installed = Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
                        if (installed < app.getLong("versionCode")) { count++; if (name == null) name = app.optString("name", app.getString("packageName")); }
                    } catch (Exception ignored) {}
                }
                if (count > 0) notifyUpdates(context, count, name);
            } catch (Exception ignored) {} finally { pending.finish(); }
        }, "VoidStoreUpdateCheck").start();
    }

    private void notifyUpdates(Context context, int count, String oneName) {
        Intent open = new Intent(context, MainActivity.class); open.putExtra("updates", true);
        PendingIntent pi = PendingIntent.getActivity(context, 88, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String title = count == 1 ? "Update verfügbar" : count + " Updates verfügbar";
        String body = count == 1 ? oneName + " kann aktualisiert werden." : "Öffne Void Store, um deine Apps zu aktualisieren.";
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, "updates") : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(pi);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(7001, b.build());
    }
}
