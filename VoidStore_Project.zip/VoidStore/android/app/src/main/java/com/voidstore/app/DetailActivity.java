package com.voidstore.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DetailActivity extends Activity {
    private final ExecutorService io = Executors.newCachedThreadPool();
    private JSONObject app;
    private LinearLayout root, reviewsBox, screenshots;
    private ImageView icon;
    private Button primary, uninstall, pause, cancel;
    private ProgressBar progress;
    private TextView progressText, ratingSummary;
    private DownloadController downloader;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        try { app = new JSONObject(getIntent().getStringExtra("app")); }
        catch (Exception e) { finish(); return; }
        setContentView(buildUi());
        bindApp();
        refreshFromServer();
        loadReviews();
    }

    @Override protected void onResume() {
        super.onResume();
        if (primary != null) updateInstallButtons();
    }

    @Override protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 24));
        root.setBackgroundColor(Ui.BG);
        scroll.addView(root);

        LinearLayout top = Ui.row(this);
        Button back = Ui.secondary(this, "‹");
        back.setTextSize(26);
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 50), Ui.dp(this, 44)));
        TextView title = Ui.text(this, "Void Store", 18, true);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tl.setMarginStart(Ui.dp(this, 12));
        top.addView(title, tl);
        root.addView(top);
        root.addView(Ui.spacer(this, 18));

        LinearLayout hero = Ui.row(this);
        icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(Ui.rounded(Ui.SURFACE_2, Ui.dp(this, 22)));
        hero.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 100), Ui.dp(this, 100)));
        LinearLayout heroInfo = new LinearLayout(this);
        heroInfo.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        hp.setMarginStart(Ui.dp(this, 16));
        hero.addView(heroInfo, hp);
        TextView name = Ui.text(this, "", 25, true); name.setTag("name"); heroInfo.addView(name);
        TextView dev = Ui.muted(this, "", 14); dev.setTag("dev"); dev.setPadding(0, Ui.dp(this, 4), 0, 0); heroInfo.addView(dev);
        TextView category = Ui.muted(this, "", 13); category.setTag("category"); category.setPadding(0, Ui.dp(this, 7), 0, 0); heroInfo.addView(category);
        root.addView(hero);

        LinearLayout metrics = Ui.row(this);
        metrics.setGravity(Gravity.CENTER);
        metrics.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 16));
        TextView rating = centeredMetric("—", "Bewertungen"); rating.setTag("metric_rating"); metrics.addView(rating, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView version = centeredMetric("—", "Version"); version.setTag("metric_version"); metrics.addView(version, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView size = centeredMetric("—", "Größe"); size.setTag("metric_size"); metrics.addView(size, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        root.addView(metrics);

        primary = Ui.primary(this, "Installieren");
        primary.setOnClickListener(v -> onPrimary());
        root.addView(primary, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 52)));
        uninstall = Ui.secondary(this, "Deinstallieren");
        uninstall.setOnClickListener(v -> uninstall());
        LinearLayout.LayoutParams up = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 48)); up.topMargin = Ui.dp(this, 8);
        root.addView(uninstall, up);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000); progress.setProgress(0); progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 10)); pp.topMargin = Ui.dp(this, 14);
        root.addView(progress, pp);
        progressText = Ui.muted(this, "", 12); progressText.setVisibility(View.GONE); progressText.setPadding(0, Ui.dp(this, 5), 0, 0); root.addView(progressText);
        LinearLayout controls = Ui.row(this); controls.setPadding(0, Ui.dp(this, 8), 0, 0);
        pause = Ui.secondary(this, "Pausieren"); pause.setVisibility(View.GONE); pause.setOnClickListener(v -> onPauseDownload());
        cancel = Ui.danger(this, "Abbrechen"); cancel.setVisibility(View.GONE); cancel.setOnClickListener(v -> { if (downloader != null) downloader.cancel(); });
        controls.addView(pause, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1); cp.setMarginStart(Ui.dp(this, 8)); controls.addView(cancel, cp);
        root.addView(controls);

        TextView screenTitle = sectionTitle("Screenshots"); root.addView(screenTitle);
        HorizontalScrollView hsv = new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false);
        screenshots = Ui.row(this); hsv.addView(screenshots); root.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 210)));

        TextView aboutTitle = sectionTitle("Über diese App"); root.addView(aboutTitle);
        TextView desc = Ui.muted(this, "", 14); desc.setTag("desc"); desc.setLineSpacing(0, 1.12f); root.addView(desc);
        TextView changesTitle = sectionTitle("Was ist neu?"); changesTitle.setTag("changes_title"); root.addView(changesTitle);
        TextView changes = Ui.muted(this, "", 14); changes.setTag("changes"); root.addView(changes);

        TextView rateTitle = sectionTitle("Bewertungen & Rezensionen"); root.addView(rateTitle);
        ratingSummary = Ui.text(this, "Noch keine Bewertungen", 18, true); root.addView(ratingSummary);
        Button rate = Ui.secondary(this, "★ App bewerten"); rate.setOnClickListener(v -> showRatingDialog());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 48)); rp.topMargin = Ui.dp(this, 10); root.addView(rate, rp);
        reviewsBox = new LinearLayout(this); reviewsBox.setOrientation(LinearLayout.VERTICAL); reviewsBox.setPadding(0, Ui.dp(this, 10), 0, 0); root.addView(reviewsBox);
        return scroll;
    }

    private TextView centeredMetric(String value, String label) {
        TextView t = Ui.text(this, value + "\n" + label, 13, true);
        t.setGravity(Gravity.CENTER); t.setLineSpacing(0, 1.15f);
        return t;
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.text(this, s, 19, true);
        t.setPadding(0, Ui.dp(this, 24), 0, Ui.dp(this, 10));
        return t;
    }

    private void bindApp() {
        try {
            ((TextView)findTagged(root, "name")).setText(app.optString("name", app.getString("packageName")));
            ((TextView)findTagged(root, "dev")).setText(app.optString("developer", "Unbekannter Entwickler"));
            ((TextView)findTagged(root, "category")).setText(app.optString("category", "App"));
            ((TextView)findTagged(root, "desc")).setText(app.optString("description", "Keine Beschreibung vorhanden."));
            TextView ch = (TextView)findTagged(root, "changes");
            TextView cht = (TextView)findTagged(root, "changes_title");
            String changelog = app.optString("changelog", "").trim();
            ch.setText(changelog);
            ch.setVisibility(changelog.isEmpty() ? View.GONE : View.VISIBLE);
            cht.setVisibility(changelog.isEmpty() ? View.GONE : View.VISIBLE);
            double avg = app.optDouble("ratingAverage", 0); int count = app.optInt("ratingCount", 0);
            ((TextView)findTagged(root, "metric_rating")).setText(count == 0 ? "—\nBewertungen" : String.format(Locale.GERMANY, "%.1f ★\n%d Bewertungen", avg, count));
            ((TextView)findTagged(root, "metric_version")).setText(app.optString("versionName", "—") + "\nVersion");
            ((TextView)findTagged(root, "metric_size")).setText(formatBytes(app.optLong("sizeBytes", 0)) + "\nGröße");
            String iconUrl = app.optString("iconUrl", ""); if (!iconUrl.isEmpty()) loadBitmap(icon, iconUrl);
            renderScreenshots();
            updateInstallButtons();
        } catch (Exception ignored) {}
    }

    private View findTagged(ViewGroup group, String tag) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View v = group.getChildAt(i);
            if (tag.equals(v.getTag())) return v;
            if (v instanceof ViewGroup) { View x = findTagged((ViewGroup)v, tag); if (x != null) return x; }
        }
        return null;
    }

    private void renderScreenshots() {
        screenshots.removeAllViews();
        JSONArray arr = app.optJSONArray("screenshotUrls");
        if (arr == null || arr.length() == 0) {
            TextView empty = Ui.muted(this, "Noch keine Screenshots hochgeladen.", 13);
            screenshots.addView(empty);
            return;
        }
        for (int i = 0; i < arr.length(); i++) {
            String path = arr.optString(i, "");
            ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setBackground(Ui.rounded(Ui.SURFACE_2, Ui.dp(this, 18)));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(this, 300), Ui.dp(this, 200)); p.setMarginEnd(Ui.dp(this, 10)); screenshots.addView(iv, p);
            if (!path.isEmpty()) loadBitmap(iv, path);
        }
    }

    private void loadBitmap(ImageView view, String path) {
        io.execute(() -> { try { Bitmap b = StoreApi.loadBitmap(this, path); if (b != null) runOnUiThread(() -> view.setImageBitmap(b)); } catch (Exception ignored) {} });
    }

    private void refreshFromServer() {
        io.execute(() -> {
            try {
                JSONObject fresh = StoreApi.getApp(this, app.getString("packageName"));
                app = fresh;
                runOnUiThread(this::bindApp);
            } catch (Exception ignored) {}
        });
    }

    private void updateInstallButtons() {
        String pkg = app.optString("packageName");
        long installed = installedVersion(pkg), newest = app.optLong("versionCode", 0);
        if (installed < 0) {
            primary.setText("Installieren"); uninstall.setVisibility(View.GONE);
        } else if (installed < newest) {
            primary.setText("Aktualisieren"); uninstall.setVisibility(View.VISIBLE);
        } else {
            primary.setText("Öffnen"); uninstall.setVisibility(View.VISIBLE);
        }
    }

    private void onPrimary() {
        long installed = installedVersion(app.optString("packageName"));
        long newest = app.optLong("versionCode", 0);
        if (installed >= newest && installed >= 0) { openInstalled(); return; }
        if (downloader == null) downloader = new DownloadController(this, app, this::onDownloadState);
        downloader.startOrResume();
    }

    private void onDownloadState(String state, long done, long total, String message) {
        runOnUiThread(() -> {
            boolean show = state.equals("downloading") || state.equals("paused") || state.equals("error");
            progress.setVisibility(show ? View.VISIBLE : View.GONE);
            progressText.setVisibility(show ? View.VISIBLE : View.GONE);
            pause.setVisibility(show ? View.VISIBLE : View.GONE);
            cancel.setVisibility(show ? View.VISIBLE : View.GONE);
            if (total > 0) progress.setProgress((int)Math.min(1000, done * 1000 / total)); else progress.setIndeterminate(state.equals("downloading"));
            String sizes = total > 0 ? formatBytes(done) + " / " + formatBytes(total) : formatBytes(done);
            progressText.setText(message + (done > 0 ? " • " + sizes : ""));
            if (state.equals("downloading")) { primary.setEnabled(false); pause.setText("Pausieren"); }
            else if (state.equals("paused") || state.equals("error")) { primary.setEnabled(true); primary.setText(state.equals("paused") ? "Fortsetzen" : "Erneut versuchen"); pause.setText("Fortsetzen"); }
            else if (state.equals("cancelled")) { primary.setEnabled(true); updateInstallButtons(); }
            else if (state.equals("ready")) { primary.setEnabled(true); updateInstallButtons(); }
            if (state.equals("error")) Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    private void onPauseDownload() {
        if (downloader == null) return;
        if (downloader.isPaused()) downloader.startOrResume(); else downloader.pause();
    }

    private void uninstall() {
        Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.optString("packageName")));
        startActivity(i);
    }

    private void openInstalled() {
        Intent i = getPackageManager().getLaunchIntentForPackage(app.optString("packageName"));
        if (i != null) startActivity(i); else Toast.makeText(this, "Diese App kann nicht direkt geöffnet werden.", Toast.LENGTH_SHORT).show();
    }

    private long installedVersion(String pkg) {
        try {
            PackageInfo p = getPackageManager().getPackageInfo(pkg, 0);
            return Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
        } catch (Exception e) { return -1; }
    }

    private void loadReviews() {
        io.execute(() -> {
            try {
                JSONObject result = StoreApi.getReviews(this, app.getString("packageName"));
                runOnUiThread(() -> renderReviews(result));
            } catch (Exception e) { runOnUiThread(() -> ratingSummary.setText("Bewertungen konnten nicht geladen werden")); }
        });
    }

    private void renderReviews(JSONObject result) {
        reviewsBox.removeAllViews();
        double avg = result.optDouble("average", 0); int count = result.optInt("count", 0);
        ratingSummary.setText(count == 0 ? "Noch keine Bewertungen" : String.format(Locale.GERMANY, "%.1f ★  ·  %d Bewertungen", avg, count));
        JSONArray arr = result.optJSONArray("reviews");
        if (arr == null || arr.length() == 0) { reviewsBox.addView(Ui.muted(this, "Sei der Erste, der diese App bewertet.", 13)); return; }
        for (int i = 0; i < Math.min(20, arr.length()); i++) {
            JSONObject r = arr.optJSONObject(i); if (r == null) continue;
            LinearLayout c = Ui.card(this);
            c.addView(Ui.text(this, r.optString("nickname", "Nutzer") + "   " + stars(r.optInt("rating", 0)), 14, true));
            String comment = r.optString("comment", "").trim();
            if (!comment.isEmpty()) { TextView t = Ui.muted(this, comment, 13); t.setPadding(0, Ui.dp(this, 6), 0, 0); c.addView(t); }
            reviewsBox.addView(c);
        }
    }

    private void showRatingDialog() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(Ui.dp(this, 22), 0, Ui.dp(this, 22), 0);
        RatingBar bar = new RatingBar(this); bar.setNumStars(5); bar.setStepSize(1f); bar.setRating(5f); box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        EditText nick = Ui.input(this, "Dein Name"); nick.setSingleLine(true); box.addView(nick, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 52)));
        EditText comment = Ui.input(this, "Kommentar (optional)"); comment.setMinLines(3); comment.setGravity(Gravity.TOP); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 120)); cp.topMargin = Ui.dp(this, 10); box.addView(comment, cp);
        AlertDialog d = new AlertDialog.Builder(this).setTitle("App bewerten").setView(box).setPositiveButton("Veröffentlichen", null).setNegativeButton("Abbrechen", null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            int rating = Math.round(bar.getRating()); String name = nick.getText().toString().trim(); String text = comment.getText().toString().trim();
            if (rating < 1) { Toast.makeText(this, "Bitte mindestens einen Stern auswählen.", Toast.LENGTH_SHORT).show(); return; }
            if (name.isEmpty()) name = "Nutzer";
            d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            String finalName = name;
            io.execute(() -> {
                try { StoreApi.postReview(this, app.optString("packageName"), finalName, rating, text); runOnUiThread(() -> { d.dismiss(); Toast.makeText(this, "Bewertung veröffentlicht", Toast.LENGTH_SHORT).show(); loadReviews(); refreshFromServer(); }); }
                catch (Exception e) { runOnUiThread(() -> { d.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true); Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); }); }
            });
        }));
        d.show();
    }

    private String stars(int n) { StringBuilder b = new StringBuilder(); for (int i = 1; i <= 5; i++) b.append(i <= n ? '★' : '☆'); return b.toString(); }
    private String formatBytes(long n) {
        if (n <= 0) return "—";
        if (n >= 1024L*1024L*1024L) return String.format(Locale.GERMANY, "%.1f GB", n / 1073741824.0);
        if (n >= 1024L*1024L) return String.format(Locale.GERMANY, "%.1f MB", n / 1048576.0);
        return String.format(Locale.GERMANY, "%.0f KB", n / 1024.0);
    }
}
