package com.voidstore.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Locale;

public final class StoreApi {
    private StoreApi() {}

    public static String server(Context c) {
        String s = c.getSharedPreferences("void_store", Context.MODE_PRIVATE).getString("server", "").trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    public static void setServer(Context c, String server) {
        c.getSharedPreferences("void_store", Context.MODE_PRIVATE).edit().putString("server", server.trim()).apply();
    }

    public static String publisherKey(Context c) {
        String key = c.getSharedPreferences("void_store", Context.MODE_PRIVATE).getString("publisher_key", "");
        if (!key.isEmpty()) return key;
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        StringBuilder b = new StringBuilder();
        for (byte x : bytes) b.append(String.format(Locale.US, "%02x", x & 0xff));
        key = b.toString();
        c.getSharedPreferences("void_store", Context.MODE_PRIVATE).edit().putString("publisher_key", key).apply();
        return key;
    }

    public static void setPublisherKey(Context c, String key) {
        c.getSharedPreferences("void_store", Context.MODE_PRIVATE).edit().putString("publisher_key", key.trim()).apply();
    }

    public static String reviewUserId(Context c) {
        String id = c.getSharedPreferences("void_store", Context.MODE_PRIVATE).getString("review_user_id", "");
        if (!id.isEmpty()) return id;
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        StringBuilder b = new StringBuilder();
        for (byte x : bytes) b.append(String.format(Locale.US, "%02x", x & 0xff));
        id = b.toString();
        c.getSharedPreferences("void_store", Context.MODE_PRIVATE).edit().putString("review_user_id", id).apply();
        return id;
    }

    public static String resolve(Context c, String path) {
        if (path == null || path.isEmpty()) return "";
        if (path.startsWith("http://") || path.startsWith("https://")) return path;
        String base = server(c);
        return base + (path.startsWith("/") ? path : "/" + path);
    }

    public static JSONArray getApps(Context c) throws Exception {
        return new JSONArray(requestText(c, "GET", "/api/apps", null, null, 15000));
    }

    public static JSONObject getApp(Context c, String pkg) throws Exception {
        return new JSONObject(requestText(c, "GET", "/api/apps/" + enc(pkg), null, null, 15000));
    }

    public static JSONObject getReviews(Context c, String pkg) throws Exception {
        return new JSONObject(requestText(c, "GET", "/api/apps/" + enc(pkg) + "/reviews", null, null, 15000));
    }

    public static JSONObject postReview(Context c, String pkg, String nickname, int rating, String comment) throws Exception {
        JSONObject body = new JSONObject();
        body.put("userId", reviewUserId(c));
        body.put("nickname", nickname);
        body.put("rating", rating);
        body.put("comment", comment);
        return new JSONObject(requestText(c, "POST", "/api/apps/" + enc(pkg) + "/reviews",
                body.toString().getBytes(StandardCharsets.UTF_8), "application/json; charset=utf-8", 20000));
    }

    public interface Progress { void onProgress(long done, long total); }

    public static JSONObject uploadApk(Context c, Uri apk, JSONObject meta, Progress progress) throws Exception {
        String q = "/api/publisher/upload?packageName=" + enc(meta.getString("packageName"))
                + "&versionCode=" + enc(String.valueOf(meta.getLong("versionCode")))
                + "&versionName=" + enc(meta.optString("versionName", ""));
        HttpURLConnection conn = open(c, q);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(120000);
        conn.setChunkedStreamingMode(64 * 1024);
        conn.setRequestProperty("Content-Type", "application/vnd.android.package-archive");
        conn.setRequestProperty("X-Publisher-Key", publisherKey(c));
        long total = -1;
        try {
            android.content.res.AssetFileDescriptor afd = c.getContentResolver().openAssetFileDescriptor(apk, "r");
            if (afd != null) { total = afd.getLength(); afd.close(); }
        } catch (Exception ignored) {}
        try (InputStream in = c.getContentResolver().openInputStream(apk); OutputStream out = conn.getOutputStream()) {
            if (in == null) throw new Exception("APK konnte nicht geöffnet werden.");
            byte[] buf = new byte[64 * 1024];
            int n; long done = 0;
            while ((n = in.read(buf)) >= 0) {
                out.write(buf, 0, n);
                done += n;
                if (progress != null) progress.onProgress(done, total);
            }
        }
        return responseJson(conn);
    }

    public static JSONObject updateMeta(Context c, String pkg, JSONObject meta) throws Exception {
        HttpURLConnection conn = open(c, "/api/publisher/apps/" + enc(pkg) + "/meta");
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(30000);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setRequestProperty("X-Publisher-Key", publisherKey(c));
        try (OutputStream out = conn.getOutputStream()) { out.write(meta.toString().getBytes(StandardCharsets.UTF_8)); }
        return responseJson(conn);
    }

    public static JSONObject uploadMedia(Context c, String pkg, Uri uri, boolean icon, int index, Progress progress) throws Exception {
        String path = icon ? "/api/publisher/apps/" + enc(pkg) + "/icon"
                : "/api/publisher/apps/" + enc(pkg) + "/screenshots?index=" + index;
        HttpURLConnection conn = open(c, path);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(60000);
        conn.setChunkedStreamingMode(32 * 1024);
        conn.setRequestProperty("X-Publisher-Key", publisherKey(c));
        String mime = c.getContentResolver().getType(uri);
        conn.setRequestProperty("Content-Type", mime == null ? "image/png" : mime);
        try (InputStream in = c.getContentResolver().openInputStream(uri); OutputStream out = conn.getOutputStream()) {
            if (in == null) throw new Exception("Bild konnte nicht geöffnet werden.");
            byte[] buf = new byte[32 * 1024]; int n; long done = 0;
            while ((n = in.read(buf)) >= 0) {
                out.write(buf, 0, n); done += n;
                if (progress != null) progress.onProgress(done, -1);
            }
        }
        return responseJson(conn);
    }

    public static Bitmap loadBitmap(Context c, String path) throws Exception {
        String url = resolve(c, path);
        if (url.isEmpty()) return null;
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(8000); conn.setReadTimeout(12000);
        int code = conn.getResponseCode();
        if (code != 200) return null;
        try (InputStream in = new BufferedInputStream(conn.getInputStream())) { return BitmapFactory.decodeStream(in); }
    }

    public static HttpURLConnection openDownload(Context c, String path, long start) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(resolve(c, path)).openConnection();
        conn.setConnectTimeout(10000); conn.setReadTimeout(60000);
        conn.setRequestProperty("Accept", "application/vnd.android.package-archive");
        if (start > 0) conn.setRequestProperty("Range", "bytes=" + start + "-");
        return conn;
    }

    private static HttpURLConnection open(Context c, String path) throws Exception {
        String base = server(c);
        if (base.isEmpty()) throw new IllegalStateException("Keine Server-Adresse eingestellt.");
        return (HttpURLConnection) new URL(resolve(c, path)).openConnection();
    }

    private static String requestText(Context c, String method, String path, byte[] body, String type, int timeout) throws Exception {
        HttpURLConnection conn = open(c, path);
        conn.setRequestMethod(method);
        conn.setConnectTimeout(10000); conn.setReadTimeout(timeout);
        conn.setRequestProperty("Accept", "application/json");
        if (body != null) {
            conn.setDoOutput(true);
            if (type != null) conn.setRequestProperty("Content-Type", type);
            try (OutputStream out = conn.getOutputStream()) { out.write(body); }
        }
        int code = conn.getResponseCode();
        String text = readAll(code >= 400 ? conn.getErrorStream() : conn.getInputStream());
        if (code < 200 || code >= 300) throw new Exception("Serverfehler " + code + ": " + text);
        return text;
    }

    private static JSONObject responseJson(HttpURLConnection conn) throws Exception {
        int code = conn.getResponseCode();
        String text = readAll(code >= 400 ? conn.getErrorStream() : conn.getInputStream());
        if (code < 200 || code >= 300) throw new Exception("Serverfehler " + code + ": " + text);
        return new JSONObject(text);
    }

    private static String enc(String s) throws Exception { return URLEncoder.encode(s, StandardCharsets.UTF_8.name()); }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder b = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) b.append(line);
            return b.toString();
        }
    }
}
