package com.voidstore.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PublisherActivity extends Activity {
    private static final int PICK_APK = 100;
    private static final int PICK_ICON = 101;
    private static final int PICK_SCREENSHOTS = 102;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private Uri apkUri, iconUri;
    private final List<Uri> screenshotUris = new ArrayList<>();
    private PackageInfo apkInfo;
    private File cachedApk;
    private EditText name, developer, category, description, changelog;
    private TextView apkStatus, mediaStatus, progressText;
    private ImageView iconPreview;
    private LinearLayout screenshotPreview;
    private ProgressBar progress;
    private Button publish;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        setContentView(buildUi());
    }

    @Override protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 28));
        root.setBackgroundColor(Ui.BG);
        scroll.addView(root);

        LinearLayout top = Ui.row(this);
        Button back = Ui.secondary(this, "‹"); back.setTextSize(26); back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 50), Ui.dp(this, 44)));
        TextView title = Ui.text(this, "App veröffentlichen", 22, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1); tp.setMarginStart(Ui.dp(this, 12)); top.addView(title, tp);
        root.addView(top);

        TextView intro = Ui.muted(this, "Du wirst Besitzer des Paketnamens. Spätere Updates und Änderungen funktionieren nur mit deinem Publisher-Key.", 13);
        intro.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 16)); root.addView(intro);

        LinearLayout apkCard = Ui.card(this);
        apkCard.addView(Ui.text(this, "1. APK auswählen", 18, true));
        apkStatus = Ui.muted(this, "Noch keine APK ausgewählt", 13); apkStatus.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10)); apkCard.addView(apkStatus);
        Button chooseApk = Ui.primary(this, "APK auswählen"); chooseApk.setOnClickListener(v -> chooseApk());
        apkCard.addView(chooseApk, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 48)));
        root.addView(apkCard);

        LinearLayout details = Ui.card(this);
        details.addView(Ui.text(this, "2. Store-Eintrag", 18, true));
        name = field(details, "App-Name");
        developer = field(details, "Entwickler / Studio");
        category = field(details, "Kategorie, z. B. Game, Tools, Social");
        description = field(details, "Beschreibung"); description.setMinLines(4); description.setGravity(Gravity.TOP);
        changelog = field(details, "Was ist neu in dieser Version?"); changelog.setMinLines(3); changelog.setGravity(Gravity.TOP);
        root.addView(details);

        LinearLayout media = Ui.card(this);
        media.addView(Ui.text(this, "3. Icon & Screenshots", 18, true));
        mediaStatus = Ui.muted(this, "Icon optional • bis zu 8 Screenshots", 13); mediaStatus.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10)); media.addView(mediaStatus);
        LinearLayout mediaButtons = Ui.row(this);
        Button iconButton = Ui.secondary(this, "App-Icon"); iconButton.setOnClickListener(v -> chooseImage(PICK_ICON, false));
        Button screensButton = Ui.secondary(this, "Screenshots"); screensButton.setOnClickListener(v -> chooseImage(PICK_SCREENSHOTS, true));
        mediaButtons.addView(iconButton, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1); sbp.setMarginStart(Ui.dp(this, 8)); mediaButtons.addView(screensButton, sbp); media.addView(mediaButtons);
        iconPreview = new ImageView(this); iconPreview.setScaleType(ImageView.ScaleType.CENTER_CROP); iconPreview.setVisibility(View.GONE);
        LinearLayout.LayoutParams ipp = new LinearLayout.LayoutParams(Ui.dp(this, 84), Ui.dp(this, 84)); ipp.topMargin = Ui.dp(this, 12); media.addView(iconPreview, ipp);
        screenshotPreview = Ui.row(this); screenshotPreview.setPadding(0, Ui.dp(this, 10), 0, 0); media.addView(screenshotPreview);
        root.addView(media);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); progress.setMax(1000); progress.setVisibility(View.GONE); root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 10)));
        progressText = Ui.muted(this, "", 12); progressText.setVisibility(View.GONE); progressText.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 8)); root.addView(progressText);
        publish = Ui.primary(this, "Im Void Store veröffentlichen"); publish.setOnClickListener(v -> publish());
        root.addView(publish, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 54)));
        return scroll;
    }

    private EditText field(LinearLayout parent, String hint) {
        EditText e = Ui.input(this, hint); e.setSingleLine(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.topMargin = Ui.dp(this, 10); parent.addView(e, p); return e;
    }

    private void chooseApk() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/vnd.android.package-archive"); startActivityForResult(i, PICK_APK);
    }

    private void chooseImage(int request, boolean multiple) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple); startActivityForResult(i, request);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == PICK_APK && data.getData() != null) {
            apkUri = data.getData(); persist(apkUri); inspectApk(apkUri);
        } else if (requestCode == PICK_ICON && data.getData() != null) {
            iconUri = data.getData(); persist(iconUri); previewIcon();
        } else if (requestCode == PICK_SCREENSHOTS) {
            screenshotUris.clear();
            ClipData clip = data.getClipData();
            if (clip != null) {
                for (int i = 0; i < Math.min(8, clip.getItemCount()); i++) { Uri u = clip.getItemAt(i).getUri(); screenshotUris.add(u); persist(u); }
            } else if (data.getData() != null) { screenshotUris.add(data.getData()); persist(data.getData()); }
            renderScreenshotPreviews();
        }
    }

    private void persist(Uri uri) {
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
    }

    private void inspectApk(Uri uri) {
        publish.setEnabled(false); apkStatus.setText("APK wird geprüft …");
        io.execute(() -> {
            try {
                cachedApk = new File(getCacheDir(), "publisher-selected.apk");
                try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(cachedApk)) {
                    if (in == null) throw new Exception("Datei konnte nicht gelesen werden.");
                    byte[] buf = new byte[64 * 1024]; int n; while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
                }
                PackageInfo p = getPackageManager().getPackageArchiveInfo(cachedApk.getAbsolutePath(), 0);
                if (p == null) throw new Exception("Keine gültige APK erkannt.");
                apkInfo = p;
                String label = p.packageName;
                try {
                    if (p.applicationInfo != null) {
                        p.applicationInfo.sourceDir = cachedApk.getAbsolutePath(); p.applicationInfo.publicSourceDir = cachedApk.getAbsolutePath();
                        CharSequence l = p.applicationInfo.loadLabel(getPackageManager()); if (l != null && l.length() > 0) label = l.toString();
                    }
                } catch (Exception ignored) {}
                long vc = Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
                String finalLabel = label;
                runOnUiThread(() -> {
                    apkStatus.setText("✓ " + p.packageName + " • Version " + (p.versionName == null ? "" : p.versionName) + " • Code " + vc);
                    if (name.getText().toString().trim().isEmpty()) name.setText(finalLabel);
                    publish.setEnabled(true);
                });
            } catch (Exception e) {
                apkInfo = null; runOnUiThread(() -> { apkStatus.setText("APK-Fehler: " + e.getMessage()); publish.setEnabled(true); });
            }
        });
    }

    private void previewIcon() {
        iconPreview.setVisibility(View.VISIBLE);
        io.execute(() -> { try { Bitmap b = android.provider.MediaStore.Images.Media.getBitmap(getContentResolver(), iconUri); runOnUiThread(() -> iconPreview.setImageBitmap(b)); } catch (Exception ignored) {} });
        updateMediaStatus();
    }

    private void renderScreenshotPreviews() {
        screenshotPreview.removeAllViews();
        int show = Math.min(4, screenshotUris.size());
        for (int i = 0; i < show; i++) {
            Uri u = screenshotUris.get(i); ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setImageURI(u);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(this, 66), Ui.dp(this, 100)); p.setMarginEnd(Ui.dp(this, 8)); screenshotPreview.addView(iv, p);
        }
        if (screenshotUris.size() > show) screenshotPreview.addView(Ui.muted(this, "+" + (screenshotUris.size() - show), 14));
        updateMediaStatus();
    }

    private void updateMediaStatus() {
        mediaStatus.setText((iconUri == null ? "Kein Icon" : "Icon ausgewählt") + " • " + screenshotUris.size() + " Screenshots");
    }

    private void publish() {
        if (StoreApi.server(this).isEmpty()) { Toast.makeText(this, "Bitte zuerst in den Void-Store-Einstellungen einen Server eintragen.", Toast.LENGTH_LONG).show(); return; }
        if (apkUri == null || apkInfo == null) { Toast.makeText(this, "Bitte zuerst eine gültige APK auswählen.", Toast.LENGTH_SHORT).show(); return; }
        String appName = name.getText().toString().trim(); if (appName.isEmpty()) { name.setError("App-Name fehlt"); return; }
        long vc = Build.VERSION.SDK_INT >= 28 ? apkInfo.getLongVersionCode() : apkInfo.versionCode;
        JSONObject upload = new JSONObject();
        JSONObject meta = new JSONObject();
        try {
            upload.put("packageName", apkInfo.packageName); upload.put("versionCode", vc); upload.put("versionName", apkInfo.versionName == null ? "" : apkInfo.versionName);
            meta.put("name", appName); meta.put("developer", developer.getText().toString().trim()); meta.put("category", category.getText().toString().trim());
            meta.put("description", description.getText().toString().trim()); meta.put("changelog", changelog.getText().toString().trim());
        } catch (Exception e) { Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); return; }

        publish.setEnabled(false); progress.setVisibility(View.VISIBLE); progressText.setVisibility(View.VISIBLE); progress.setIndeterminate(false); progress.setProgress(0); progressText.setText("APK wird hochgeladen …");
        io.execute(() -> {
            try {
                StoreApi.uploadApk(this, apkUri, upload, (done,total) -> runOnUiThread(() -> {
                    if (total > 0) progress.setProgress((int)Math.min(650, done * 650 / total));
                    progressText.setText("APK: " + formatBytes(done) + (total > 0 ? " / " + formatBytes(total) : ""));
                }));
                runOnUiThread(() -> { progress.setProgress(680); progressText.setText("Store-Daten werden gespeichert …"); });
                StoreApi.updateMeta(this, apkInfo.packageName, meta);
                if (iconUri != null) {
                    runOnUiThread(() -> progressText.setText("App-Icon wird hochgeladen …"));
                    StoreApi.uploadMedia(this, apkInfo.packageName, iconUri, true, 0, null);
                }
                for (int i = 0; i < screenshotUris.size(); i++) {
                    int idx = i; runOnUiThread(() -> { progress.setProgress(720 + (int)(260.0 * idx / Math.max(1, screenshotUris.size()))); progressText.setText("Screenshot " + (idx + 1) + " / " + screenshotUris.size()); });
                    StoreApi.uploadMedia(this, apkInfo.packageName, screenshotUris.get(i), false, i, null);
                }
                runOnUiThread(() -> {
                    progress.setProgress(1000); progressText.setText("Veröffentlicht ✓"); Toast.makeText(this, "App wurde im Void Store veröffentlicht.", Toast.LENGTH_LONG).show();
                    publish.setEnabled(true);
                    Intent i = new Intent(this, MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); startActivity(i); finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> { publish.setEnabled(true); progressText.setText("Fehler: " + e.getMessage()); Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); });
            }
        });
    }

    private String formatBytes(long n) {
        if (n >= 1024L*1024L) return String.format(Locale.GERMANY, "%.1f MB", n / 1048576.0);
        if (n >= 1024L) return String.format(Locale.GERMANY, "%.0f KB", n / 1024.0);
        return n + " B";
    }
}
