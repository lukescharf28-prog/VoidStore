package com.voidstore.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService io = Executors.newCachedThreadPool();
    private final List<JSONObject> allApps = new ArrayList<>();
    private LinearLayout list;
    private TextView status;
    private EditText search;
    private Button tabHome, tabUpdates;
    private boolean updatesOnly;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        createNotificationChannel();
        UpdateScheduler.schedule(this);
        requestNotificationPermission();
        setContentView(buildUi());
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        if (!allApps.isEmpty()) renderCurrent();
    }

    @Override protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        root.setBackgroundColor(Ui.BG);

        LinearLayout top = Ui.row(this);
        TextView logo = Ui.text(this, "VOID", 26, true);
        logo.setLetterSpacing(.14f);
        logo.setTextColor(Ui.PURPLE_2);
        top.addView(logo, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button publish = Ui.secondary(this, "+ Veröffentlichen");
        publish.setOnClickListener(v -> startActivity(new Intent(this, PublisherActivity.class)));
        top.addView(publish, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(this, 44)));
        Button settings = Ui.secondary(this, "⚙");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 44));
        sp.setMarginStart(Ui.dp(this, 8));
        top.addView(settings, sp);
        settings.setOnClickListener(v -> showSettings());
        root.addView(top);

        TextView subtitle = Ui.muted(this, "Store für deine Apps & Games", 13);
        subtitle.setPadding(0, 0, 0, Ui.dp(this, 12));
        root.addView(subtitle);

        search = Ui.input(this, "Apps & Games suchen");
        search.setSingleLine(true);
        search.setCompoundDrawablePadding(Ui.dp(this, 8));
        root.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 50)));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { renderCurrent(); }
            @Override public void afterTextChanged(Editable e) {}
        });

        LinearLayout tabs = Ui.row(this);
        tabs.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 8));
        tabHome = pill("Für dich", true);
        tabUpdates = pill("Updates", false);
        tabs.addView(tabHome);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.setMarginStart(Ui.dp(this, 8));
        tabs.addView(tabUpdates, tp);
        tabHome.setOnClickListener(v -> { updatesOnly = false; styleTabs(); renderCurrent(); });
        tabUpdates.setOnClickListener(v -> { updatesOnly = true; styleTabs(); renderCurrent(); });
        root.addView(tabs);

        status = Ui.muted(this, "", 12);
        status.setPadding(0, 0, 0, Ui.dp(this, 8));
        root.addView(status);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return root;
    }

    private Button pill(String text, boolean selected) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), 0);
        b.setMinHeight(0); b.setMinimumHeight(0); b.setMinWidth(0); b.setMinimumWidth(0);
        stylePill(b, selected);
        return b;
    }

    private void styleTabs() {
        stylePill(tabHome, !updatesOnly);
        stylePill(tabUpdates, updatesOnly);
    }

    private void stylePill(Button b, boolean selected) {
        b.setTextColor(selected ? Color.rgb(22,13,31) : Ui.TEXT);
        b.setBackground(Ui.rounded(selected ? Ui.PURPLE : Ui.SURFACE_2, Ui.dp(this, 20)));
    }

    private void refresh() {
        if (StoreApi.server(this).isEmpty()) {
            status.setText("Noch kein Void-Server verbunden");
            list.removeAllViews();
            addWelcomeCard();
            return;
        }
        status.setText("Store wird geladen …");
        list.removeAllViews();
        ProgressBar p = new ProgressBar(this);
        p.setIndeterminate(true);
        list.addView(p);
        io.execute(() -> {
            try {
                JSONArray arr = StoreApi.getApps(this);
                allApps.clear();
                for (int i = 0; i < arr.length(); i++) allApps.add(arr.getJSONObject(i));
                runOnUiThread(this::renderCurrent);
            } catch (Exception e) {
                runOnUiThread(() -> {
                    list.removeAllViews();
                    status.setText("Server nicht erreichbar");
                    LinearLayout c = Ui.card(this);
                    c.addView(Ui.text(this, "Verbindung fehlgeschlagen", 18, true));
                    TextView m = Ui.muted(this, e.getMessage(), 13);
                    m.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
                    c.addView(m);
                    Button retry = Ui.primary(this, "Erneut versuchen");
                    retry.setOnClickListener(v -> refresh());
                    c.addView(retry, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46)));
                    list.addView(c);
                });
            }
        });
    }

    private void renderCurrent() {
        if (list == null) return;
        list.removeAllViews();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int updateCount = 0;
        int shown = 0;
        for (JSONObject app : allApps) {
            try {
                long installed = installedVersion(app.getString("packageName"));
                long newest = app.getLong("versionCode");
                boolean hasUpdate = installed >= 0 && installed < newest;
                if (hasUpdate) updateCount++;
                if (updatesOnly && !hasUpdate) continue;
                String hay = (app.optString("name") + " " + app.optString("developer") + " " + app.optString("category") + " " + app.optString("description")).toLowerCase(Locale.ROOT);
                if (!q.isEmpty() && !hay.contains(q)) continue;
                addAppCard(app, installed, hasUpdate);
                shown++;
            } catch (Exception ignored) {}
        }
        tabUpdates.setText(updateCount > 0 ? "Updates  " + updateCount : "Updates");
        status.setText(allApps.size() + " Apps • " + updateCount + " Updates verfügbar");
        if (shown == 0) {
            LinearLayout empty = Ui.card(this);
            empty.addView(Ui.text(this, updatesOnly ? "Alles aktuell ✨" : "Keine Treffer", 18, true));
            empty.addView(Ui.muted(this, updatesOnly ? "Für deine installierten Apps gibt es gerade kein Update." : "Versuche einen anderen Suchbegriff.", 13));
            list.addView(empty);
        }
    }

    private void addWelcomeCard() {
        LinearLayout c = Ui.card(this);
        TextView h = Ui.text(this, "Void Store ist bereit", 21, true);
        c.addView(h);
        TextView m = Ui.muted(this, "Trage einmal die Adresse deines Void-Servers ein. Danach sehen alle Geräte dieselben Apps, Updates, Bewertungen und Kommentare.", 14);
        m.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 14));
        c.addView(m);
        Button b = Ui.primary(this, "Server verbinden");
        b.setOnClickListener(v -> showSettings());
        c.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 48)));
        list.addView(c);
    }

    private void addAppCard(JSONObject app, long installed, boolean hasUpdate) throws Exception {
        LinearLayout card = Ui.card(this);
        card.setClickable(true);
        card.setOnClickListener(v -> openDetails(app));

        LinearLayout row = Ui.row(this);
        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        icon.setBackground(Ui.rounded(Ui.SURFACE_2, Ui.dp(this, 18)));
        row.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 72), Ui.dp(this, 72)));
        String iconUrl = app.optString("iconUrl", "");
        if (!iconUrl.isEmpty()) loadImage(icon, iconUrl);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        ip.setMarginStart(Ui.dp(this, 14));
        row.addView(info, ip);
        info.addView(Ui.text(this, app.optString("name", app.getString("packageName")), 18, true));
        String dev = app.optString("developer", "Unbekannter Entwickler");
        info.addView(Ui.muted(this, dev, 13));
        double rating = app.optDouble("ratingAverage", 0);
        int count = app.optInt("ratingCount", 0);
        String ratingText = count == 0 ? "Noch keine Bewertungen" : String.format(Locale.GERMANY, "★ %.1f  ·  %d", rating, count);
        TextView r = Ui.muted(this, ratingText, 13);
        r.setPadding(0, Ui.dp(this, 6), 0, 0);
        info.addView(r);
        row.addView(info);
        card.addView(row);

        String shortDesc = app.optString("description", "").trim();
        if (!shortDesc.isEmpty()) {
            TextView d = Ui.muted(this, shortDesc.length() > 150 ? shortDesc.substring(0, 147) + "…" : shortDesc, 13);
            d.setPadding(0, Ui.dp(this, 12), 0, 0);
            d.setMaxLines(2);
            card.addView(d);
        }

        LinearLayout buttons = Ui.row(this);
        buttons.setPadding(0, Ui.dp(this, 12), 0, 0);
        String primaryText = installed < 0 ? "Installieren" : hasUpdate ? "Aktualisieren" : "Öffnen";
        Button primary = Ui.primary(this, primaryText);
        buttons.addView(primary, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        primary.setOnClickListener(v -> {
            v.getParent().requestDisallowInterceptTouchEvent(true);
            if (installed >= 0 && !hasUpdate) openInstalled(app.optString("packageName"));
            else openDetails(app);
        });
        card.addView(buttons);
        list.addView(card);
    }

    private void loadImage(ImageView view, String path) {
        io.execute(() -> {
            try {
                Bitmap b = StoreApi.loadBitmap(this, path);
                if (b != null) runOnUiThread(() -> view.setImageBitmap(b));
            } catch (Exception ignored) {}
        });
    }

    private void openDetails(JSONObject app) {
        Intent i = new Intent(this, DetailActivity.class);
        i.putExtra("app", app.toString());
        startActivity(i);
    }

    private void openInstalled(String pkg) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) throw new Exception();
            startActivity(i);
        } catch (Exception e) { Toast.makeText(this, "Diese App hat keine startbare Oberfläche.", Toast.LENGTH_SHORT).show(); }
    }

    private long installedVersion(String pkg) {
        try {
            PackageInfo p = getPackageManager().getPackageInfo(pkg, 0);
            return Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode;
        } catch (Exception e) { return -1; }
    }

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(this, 22), 0, Ui.dp(this, 22), 0);
        EditText server = Ui.input(this, "https://store.example.com");
        server.setSingleLine(true);
        server.setText(StoreApi.server(this));
        box.addView(Ui.text(this, "Server-Adresse", 14, true));
        box.addView(server, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 52)));
        TextView ptitle = Ui.text(this, "Publisher-Key", 14, true);
        ptitle.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 5));
        box.addView(ptitle);
        EditText key = Ui.input(this, "Publisher-Key");
        key.setSingleLine(true);
        key.setText(StoreApi.publisherKey(this));
        box.addView(key, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 52)));
        TextView note = Ui.muted(this, "Wichtig: Dieser Schlüssel beweist, welche Apps dir gehören. Sichere ihn, bevor du dein Handy wechselst.", 12);
        note.setPadding(0, Ui.dp(this, 8), 0, 0);
        box.addView(note);
        Button copy = Ui.secondary(this, "Publisher-Key kopieren");
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Void Store Publisher Key", key.getText().toString()));
            Toast.makeText(this, "Publisher-Key kopiert", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 46));
        cp.topMargin = Ui.dp(this, 10);
        box.addView(copy, cp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Void Store Einstellungen")
                .setView(box)
                .setPositiveButton("Speichern", null)
                .setNegativeButton("Abbrechen", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String s = server.getText().toString().trim();
            String k = key.getText().toString().trim();
            if (!k.matches("[0-9a-fA-F]{64}")) {
                key.setError("Der Publisher-Key muss 64 Hex-Zeichen haben.");
                return;
            }
            StoreApi.setServer(this, s);
            StoreApi.setPublisherKey(this, k.toLowerCase(Locale.ROOT));
            dialog.dismiss();
            refresh();
        }));
        dialog.show();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 77);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("updates", "Void Store Updates", NotificationManager.IMPORTANCE_DEFAULT));
        }
    }
}
