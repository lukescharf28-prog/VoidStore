'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 8080);
const ROOT = __dirname;
const DATA = path.join(ROOT, 'data');
const APK_DIR = path.join(DATA, 'apks');
const MEDIA_DIR = path.join(DATA, 'media');
const APPS_DB = path.join(DATA, 'apps.json');
const REVIEWS_DB = path.join(DATA, 'reviews.json');
const PUBLIC = path.join(ROOT, 'public');
const MAX_APK = Number(process.env.MAX_APK_MB || 1000) * 1024 * 1024;
const MAX_MEDIA = Number(process.env.MAX_MEDIA_MB || 20) * 1024 * 1024;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';

fs.mkdirSync(APK_DIR, { recursive: true });
fs.mkdirSync(MEDIA_DIR, { recursive: true });
if (!fs.existsSync(APPS_DB)) fs.writeFileSync(APPS_DB, '[]');
if (!fs.existsSync(REVIEWS_DB)) fs.writeFileSync(REVIEWS_DB, '{}');

function loadJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function atomicJson(file, value) {
  const temp = file + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(value, null, 2));
  fs.renameSync(temp, file);
}
function loadApps() { return loadJson(APPS_DB, []); }
function saveApps(v) { atomicJson(APPS_DB, v); }
function loadReviews() { return loadJson(REVIEWS_DB, {}); }
function saveReviews(v) { atomicJson(REVIEWS_DB, v); }

function json(res, code, value) {
  const body = Buffer.from(JSON.stringify(value));
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(body);
}

function safePackage(s) { return /^[A-Za-z0-9_.]{3,200}$/.test(s || '') ? s : null; }
function safeKey(s) { return /^[0-9a-fA-F]{64}$/.test(s || '') ? s.toLowerCase() : null; }
function ownerHash(key) { return crypto.createHash('sha256').update(key).digest('hex'); }
function appByPackage(apps, pkg) { return apps.find(a => a.packageName === pkg); }
function ownerOk(req, app) {
  if (ADMIN_TOKEN && req.headers['x-admin-token'] === ADMIN_TOKEN) return true;
  const key = safeKey(req.headers['x-publisher-key']);
  return !!key && app && app.ownerHash === ownerHash(key);
}
function requirePublisher(req, res) {
  const key = safeKey(req.headers['x-publisher-key']);
  if (!key) { json(res, 401, { error: 'Publisher-Key fehlt oder ist ungültig' }); return null; }
  return key;
}
function publicApp(app, reviews) {
  const list = Array.isArray(reviews[app.packageName]) ? reviews[app.packageName] : [];
  const count = list.length;
  const avg = count ? list.reduce((s, r) => s + Number(r.rating || 0), 0) / count : 0;
  const out = { ...app };
  delete out.ownerHash;
  out.ratingAverage = Math.round(avg * 10) / 10;
  out.ratingCount = count;
  out.downloadUrl = `/api/apps/${encodeURIComponent(app.packageName)}/download`;
  out.iconUrl = app.hasIcon ? `/api/apps/${encodeURIComponent(app.packageName)}/icon` : '';
  out.screenshotUrls = Array.from({ length: Number(app.screenshotCount || 0) }, (_, i) => `/api/apps/${encodeURIComponent(app.packageName)}/screenshots/${i}`);
  return out;
}
function contentTypeFrom(req, fallback) {
  const v = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  return v.startsWith('image/') ? v : fallback;
}

function serveFile(req, res, file, contentType, cache = 'public, max-age=60') {
  if (!fs.existsSync(file)) return json(res, 404, { error: 'Not found' });
  const stat = fs.statSync(file);
  const range = req.headers.range;
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Content-Type', contentType);
  res.setHeader('Cache-Control', cache);
  if (range) {
    const m = /^bytes=(\d+)-(\d*)$/.exec(range);
    if (!m) { res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` }); return res.end(); }
    const start = Number(m[1]);
    const end = m[2] ? Math.min(Number(m[2]), stat.size - 1) : stat.size - 1;
    if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start >= stat.size || end < start) {
      res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` }); return res.end();
    }
    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${stat.size}`,
      'Content-Length': end - start + 1
    });
    return fs.createReadStream(file, { start, end }).pipe(res);
  }
  res.setHeader('Content-Length', stat.size);
  res.writeHead(200);
  fs.createReadStream(file).pipe(res);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > limit) { reject(new Error('Body too large')); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function streamUpload(req, target, maxBytes) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const temp = target + '.uploading';
    const out = fs.createWriteStream(temp);
    let bytes = 0; let failed = false;
    const fail = err => {
      if (failed) return; failed = true;
      try { out.destroy(); } catch {}
      try { fs.unlinkSync(temp); } catch {}
      reject(err);
    };
    req.on('data', chunk => {
      bytes += chunk.length;
      if (bytes > maxBytes) fail(new Error('Upload too large'));
    });
    req.on('error', fail);
    out.on('error', fail);
    out.on('finish', () => {
      if (failed) return;
      try { fs.renameSync(temp, target); resolve(bytes); } catch (e) { fail(e); }
    });
    req.pipe(out);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, X-Publisher-Key, X-Admin-Token, Range',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      });
      return res.end();
    }

    if (req.method === 'GET' && u.pathname === '/api/health') return json(res, 200, { ok: true, app: 'Void Store Server', version: 2 });

    if (req.method === 'GET' && u.pathname === '/api/apps') {
      const apps = loadApps().sort((a,b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
      const reviews = loadReviews();
      return json(res, 200, apps.map(a => publicApp(a, reviews)));
    }

    const appRoute = u.pathname.match(/^\/api\/apps\/([^/]+)$/);
    if (req.method === 'GET' && appRoute) {
      const pkg = safePackage(decodeURIComponent(appRoute[1]));
      const app = appByPackage(loadApps(), pkg);
      if (!app) return json(res, 404, { error: 'Unknown app' });
      return json(res, 200, publicApp(app, loadReviews()));
    }

    const downloadRoute = u.pathname.match(/^\/api\/apps\/([^/]+)\/download$/);
    if (req.method === 'GET' && downloadRoute) {
      const pkg = safePackage(decodeURIComponent(downloadRoute[1]));
      const apps = loadApps(); const app = appByPackage(apps, pkg);
      if (!app) return json(res, 404, { error: 'Unknown app' });
      const file = path.join(APK_DIR, pkg, `${app.versionCode}.apk`);
      res.setHeader('Content-Disposition', `attachment; filename="${pkg}-${app.versionCode}.apk"`);
      if (!req.headers.range) {
        app.downloadCount = Number(app.downloadCount || 0) + 1;
        saveApps(apps);
      }
      return serveFile(req, res, file, 'application/vnd.android.package-archive', 'no-store');
    }

    const iconRoute = u.pathname.match(/^\/api\/apps\/([^/]+)\/icon$/);
    if (req.method === 'GET' && iconRoute) {
      const pkg = safePackage(decodeURIComponent(iconRoute[1]));
      const app = appByPackage(loadApps(), pkg);
      if (!app || !app.hasIcon) return json(res, 404, { error: 'No icon' });
      return serveFile(req, res, path.join(MEDIA_DIR, pkg, 'icon.bin'), app.iconType || 'image/png', 'public, max-age=300');
    }

    const screenshotRoute = u.pathname.match(/^\/api\/apps\/([^/]+)\/screenshots\/(\d+)$/);
    if (req.method === 'GET' && screenshotRoute) {
      const pkg = safePackage(decodeURIComponent(screenshotRoute[1]));
      const index = Number(screenshotRoute[2]);
      const app = appByPackage(loadApps(), pkg);
      if (!app || index < 0 || index >= Number(app.screenshotCount || 0)) return json(res, 404, { error: 'No screenshot' });
      const types = Array.isArray(app.screenshotTypes) ? app.screenshotTypes : [];
      return serveFile(req, res, path.join(MEDIA_DIR, pkg, `screen-${index}.bin`), types[index] || 'image/jpeg', 'public, max-age=300');
    }

    const reviewsRoute = u.pathname.match(/^\/api\/apps\/([^/]+)\/reviews$/);
    if (reviewsRoute && req.method === 'GET') {
      const pkg = safePackage(decodeURIComponent(reviewsRoute[1]));
      if (!appByPackage(loadApps(), pkg)) return json(res, 404, { error: 'Unknown app' });
      const db = loadReviews(); const list = Array.isArray(db[pkg]) ? db[pkg] : [];
      const average = list.length ? list.reduce((s,r) => s + Number(r.rating || 0), 0) / list.length : 0;
      const clean = list.map(({ userId, ...r }) => r).sort((a,b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
      return json(res, 200, { average: Math.round(average * 10) / 10, count: list.length, reviews: clean });
    }

    if (reviewsRoute && req.method === 'POST') {
      const pkg = safePackage(decodeURIComponent(reviewsRoute[1]));
      if (!appByPackage(loadApps(), pkg)) return json(res, 404, { error: 'Unknown app' });
      const raw = await readBody(req, 24 * 1024);
      let body; try { body = JSON.parse(raw.toString('utf8')); } catch { return json(res, 400, { error: 'Invalid JSON' }); }
      const userId = /^[0-9a-fA-F]{32}$/.test(body.userId || '') ? body.userId.toLowerCase() : null;
      const rating = Number(body.rating);
      const nickname = String(body.nickname || 'Nutzer').trim().slice(0, 40) || 'Nutzer';
      const comment = String(body.comment || '').trim().slice(0, 1200);
      if (!userId || !Number.isInteger(rating) || rating < 1 || rating > 5) return json(res, 400, { error: 'userId and rating 1-5 required' });
      const db = loadReviews(); const list = Array.isArray(db[pkg]) ? db[pkg] : [];
      const now = new Date().toISOString(); const idx = list.findIndex(r => r.userId === userId);
      const item = { id: idx >= 0 ? list[idx].id : crypto.randomUUID(), userId, nickname, rating, comment, createdAt: idx >= 0 ? list[idx].createdAt : now, updatedAt: now };
      if (idx >= 0) list[idx] = item; else list.push(item);
      db[pkg] = list.slice(-5000); saveReviews(db);
      return json(res, 201, { ok: true });
    }

    if (req.method === 'POST' && u.pathname === '/api/publisher/upload') {
      const key = requirePublisher(req, res); if (!key) return;
      const pkg = safePackage(u.searchParams.get('packageName'));
      const versionCode = Number(u.searchParams.get('versionCode'));
      const versionName = String(u.searchParams.get('versionName') || '').slice(0, 100);
      if (!pkg || !Number.isSafeInteger(versionCode) || versionCode < 1) return json(res, 400, { error: 'packageName and positive versionCode required' });
      const apps = loadApps(); const old = appByPackage(apps, pkg); const hash = ownerHash(key);
      if (old && old.ownerHash !== hash && !(ADMIN_TOKEN && req.headers['x-admin-token'] === ADMIN_TOKEN)) return json(res, 403, { error: 'Dieser Paketname gehört einem anderen Publisher-Key.' });
      if (old && Number(old.versionCode) > versionCode) return json(res, 409, { error: `Neuere Version ${old.versionCode} ist bereits online.` });
      const file = path.join(APK_DIR, pkg, `${versionCode}.apk`);
      let bytes;
      try { bytes = await streamUpload(req, file, MAX_APK); } catch (e) { return json(res, 413, { error: e.message }); }
      if (bytes < 4) { try { fs.unlinkSync(file); } catch {} return json(res, 400, { error: 'APK body is empty' }); }
      const entry = {
        packageName: pkg,
        name: old?.name || pkg,
        developer: old?.developer || '',
        category: old?.category || 'App',
        description: old?.description || '',
        changelog: old?.changelog || '',
        versionCode,
        versionName,
        sizeBytes: bytes,
        ownerHash: old?.ownerHash || hash,
        hasIcon: !!old?.hasIcon,
        iconType: old?.iconType || 'image/png',
        screenshotCount: Number(old?.screenshotCount || 0),
        screenshotTypes: Array.isArray(old?.screenshotTypes) ? old.screenshotTypes : [],
        downloadCount: Number(old?.downloadCount || 0),
        createdAt: old?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      const idx = apps.findIndex(a => a.packageName === pkg); if (idx >= 0) apps[idx] = entry; else apps.unshift(entry); saveApps(apps);
      return json(res, 201, { ok: true, app: publicApp(entry, loadReviews()) });
    }

    const metaRoute = u.pathname.match(/^\/api\/publisher\/apps\/([^/]+)\/meta$/);
    if (req.method === 'POST' && metaRoute) {
      const pkg = safePackage(decodeURIComponent(metaRoute[1])); const apps = loadApps(); const app = appByPackage(apps, pkg);
      if (!app) return json(res, 404, { error: 'Unknown app' });
      if (!ownerOk(req, app)) return json(res, 403, { error: 'Falscher Publisher-Key.' });
      const raw = await readBody(req, 64 * 1024); let body; try { body = JSON.parse(raw.toString('utf8')); } catch { return json(res, 400, { error: 'Invalid JSON' }); }
      app.name = String(body.name || app.name || pkg).trim().slice(0, 100) || pkg;
      app.developer = String(body.developer || '').trim().slice(0, 100);
      app.category = String(body.category || 'App').trim().slice(0, 60) || 'App';
      app.description = String(body.description || '').trim().slice(0, 6000);
      app.changelog = String(body.changelog || '').trim().slice(0, 4000);
      app.updatedAt = new Date().toISOString(); saveApps(apps);
      return json(res, 200, { ok: true, app: publicApp(app, loadReviews()) });
    }

    const iconUpload = u.pathname.match(/^\/api\/publisher\/apps\/([^/]+)\/icon$/);
    if (req.method === 'POST' && iconUpload) {
      const pkg = safePackage(decodeURIComponent(iconUpload[1])); const apps = loadApps(); const app = appByPackage(apps, pkg);
      if (!app) return json(res, 404, { error: 'Unknown app' });
      if (!ownerOk(req, app)) return json(res, 403, { error: 'Falscher Publisher-Key.' });
      const target = path.join(MEDIA_DIR, pkg, 'icon.bin');
      try { await streamUpload(req, target, MAX_MEDIA); } catch (e) { return json(res, 413, { error: e.message }); }
      app.hasIcon = true; app.iconType = contentTypeFrom(req, 'image/png'); app.updatedAt = new Date().toISOString(); saveApps(apps);
      return json(res, 201, { ok: true, iconUrl: `/api/apps/${encodeURIComponent(pkg)}/icon` });
    }

    const screenUpload = u.pathname.match(/^\/api\/publisher\/apps\/([^/]+)\/screenshots$/);
    if (req.method === 'POST' && screenUpload) {
      const pkg = safePackage(decodeURIComponent(screenUpload[1])); const index = Number(u.searchParams.get('index'));
      if (!Number.isInteger(index) || index < 0 || index > 7) return json(res, 400, { error: 'index must be 0-7' });
      const apps = loadApps(); const app = appByPackage(apps, pkg);
      if (!app) return json(res, 404, { error: 'Unknown app' });
      if (!ownerOk(req, app)) return json(res, 403, { error: 'Falscher Publisher-Key.' });
      const target = path.join(MEDIA_DIR, pkg, `screen-${index}.bin`);
      try { await streamUpload(req, target, MAX_MEDIA); } catch (e) { return json(res, 413, { error: e.message }); }
      app.screenshotCount = Math.max(Number(app.screenshotCount || 0), index + 1);
      const types = Array.isArray(app.screenshotTypes) ? app.screenshotTypes : []; types[index] = contentTypeFrom(req, 'image/jpeg'); app.screenshotTypes = types;
      app.updatedAt = new Date().toISOString(); saveApps(apps);
      return json(res, 201, { ok: true });
    }

    if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/admin')) {
      return serveFile(req, res, path.join(PUBLIC, 'admin.html'), 'text/html; charset=utf-8', 'no-store');
    }

    return json(res, 404, { error: 'Not found' });
  } catch (e) {
    if (!res.headersSent) json(res, 500, { error: e.message || 'Internal server error' }); else res.end();
  }
});

server.listen(PORT, '0.0.0.0', () => console.log(`Void Store Server läuft auf Port ${PORT}`));
