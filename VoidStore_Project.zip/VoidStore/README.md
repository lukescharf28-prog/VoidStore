# Void Store

Ein eigener Android-App-Store für APKs mit moderner Store-Oberfläche.

## Funktionen

- Play-Store-artige App-Seiten mit Icon, Entwickler, Version, Größe, Screenshots und Beschreibung
- Installieren / Aktualisieren / Öffnen
- Bei installierten Apps direkt darunter: Deinstallieren
- APK-Downloads mit Fortschritt, Pausieren, Fortsetzen und Abbrechen
- Automatische Update-Prüfung im Hintergrund und Android-Benachrichtigung
- Upload direkt in der Android-App: APK, App-Name, Entwickler, Kategorie, Beschreibung, Changelog, Icon, bis zu 8 Screenshots
- Publisher-Keys: Der erste Uploader besitzt einen Paketnamen; nur sein Schlüssel darf Updates/Metadaten verändern
- 1–5 Sterne, Kommentare und Bewertungsdurchschnitt
- Server unterstützt HTTP Range für fortsetzbare Downloads
- Fester Release-Signaturschlüssel für spätere Void-Store-Updates

## Ordner

- `android/` – native Android-App (Java, minSdk 29, targetSdk 35)
- `server/` – Node.js-Backend ohne npm-Abhängigkeiten
- `.github/workflows/android-build.yml` – baut eine installierbare signierte APK in GitHub Actions

## Wichtig: Server

Alle Geräte müssen dieselbe öffentlich erreichbare HTTPS-Adresse in den Void-Store-Einstellungen verwenden. Der Server braucht persistenten Speicher, weil dort APKs, Icons, Screenshots, Bewertungen und Kommentare liegen.

Lokal startet der Server mit:

```bash
cd server
node server.js
```

Standardport: `8080`.

## Publisher-Key

Beim ersten Start erzeugt jedes Gerät automatisch einen 64-stelligen Publisher-Key. Sichere ihn. Wer denselben Publisher-Key besitzt, kann Updates zu den damit veröffentlichten Paketnamen hochladen.

## APK-Build ohne Android Studio

Das Repository ist bereits für GitHub Actions vorbereitet. Es sollte wegen `android/voidstore-release.jks` als **privates Repository** verwendet werden. Unter GitHub → Actions → `Build Void Store APK` → `Run workflow` wird `VoidStore.apk` als Build-Artefakt erzeugt.

Der enthaltene Release-Key darf nicht öffentlich geteilt werden. Ohne denselben Key können spätere APKs nicht als Update über die bestehende Void-Store-Installation installiert werden.
